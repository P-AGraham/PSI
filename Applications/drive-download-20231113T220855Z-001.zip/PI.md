# Cool sentences 
I said I was going to apply this year and here I am! 