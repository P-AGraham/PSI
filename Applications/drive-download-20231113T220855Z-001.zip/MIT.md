# Interesting teachers 
Netta Engelhardt
Daniel Harlow
Edward Farhi

# Recommendations
Dr. André-Marie Tremblay
Université de Sherbrooke
andre-marie.tremblay@usherbrooke.ca 

Dr. Ion Garate 	
Université de Sherbrooke 	
ion.garate.aramberri@usherbrooke.ca

Dr. Valerio Faraoni
Bishop's University
vfaraoni@ubishops.ca 	

# Plan and Ideas

What can I conclude from my past experience?
What I would like to do is Combine two seemingly unrelated subjects to solve new problems.  

How did I get to this realisation? 
multidisciplinary passion led me to explore many different domains. 

First internship:
My first internship took place in Jeffrey Quilliam's group. 
I was working on a python GUI aiming to treat NMR data for the study of a magnetically frustrated cystal under high pressure. I managed to reproduce all the key features needed in the interface including Fourier analysis and fitting tools.


Second internship:
I got the change to developp my data analysis skill further when I took part in the research 

My fist real contact with quantum many body physics happened during my second internship in the André-Marie 


