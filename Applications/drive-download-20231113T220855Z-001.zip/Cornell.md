Teaching is important: The reinforce material and developp interpersonnal skills. https://physics.cornell.edu/prospective-graduate-students

Successful applicants demonstrate the potential to master physics concepts at the graduate level, and show the creativity, initiative, attentiveness, and determination to succeed in research. Students with less preparation but demonstrated potential have the opportunity to fill knowledge gaps by taking one or more undergraduate level courses in their first year

If multidisciplinary collaboration is one attribute of Cornell’s graduate program in physics, the breadth of its curriculum and faculty is another.

Among graduate students, relationships are more cooperative than competitive.

https://physics.cornell.edu/about-graduate-program


Saul Teukolsky, https://physics.cornell.edu/saul-teukolsky

Eun-Ah Kim, https://physics.cornell.edu/news/physicist-identifies-how-electron-crystals-melt


Science letters and arts (multidisciplinary)

Dont forget the paragraph about college

# I think the multidisciplinary aspects of my past experiences make me a great fit for the collaborative environnement at cornell.

%Last summer, I participated to a summer school at Perimeter Institute where I got to meet people from all around the world and truely appreciate diversity in physics. 

During the semester following this internship I developped my interest in topological materials further by working on a short litterature review of the basis of the field. 