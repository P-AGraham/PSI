#include "twoBody.c"
#include "L2.c"

#include "twoBody_Z2.c"
#include "L2_Z2.c"

#include "twoBody_Z2PH.c"
#include "L2_Z2PH.c"

#include "nlm.c"
#include "General_operators.c"

#include "lineDefect.c"

#include "spmv.c"

