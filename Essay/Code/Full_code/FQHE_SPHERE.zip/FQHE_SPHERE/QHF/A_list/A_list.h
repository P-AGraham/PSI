
void cal2BodyAlist(struct CG2 *cg, double *pseudo, double *A_list2, int num_thread);

void setCoulomb(double *pseudo, size_t N_phi);