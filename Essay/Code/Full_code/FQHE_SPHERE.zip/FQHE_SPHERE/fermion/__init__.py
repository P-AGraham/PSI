#FQHE/fermion/__init__.py
#from .singlelayer import FermionSL as sl
#from .singlelayer import fqhe_sl_solver as sl_solver
#from .threelayers import FermionTL as tl
#from .threelayers import fqhe_tl_solver as tl_solver
#from .doublelayers import FermionDL as dl
#from .doublelayers import fqhe_dl_solver as dl_solver
from .doublelayers import QHFMFermionDL as QHFM
from .doublelayers import fqhe_dl_solver as dl_solver